const Discord = require('discord.js');

exports.run = (bot, message, args) => {

  
  let embed = new Discord.MessageEmbed()
  .setDescription(`Escolha o seu emprego, clicando no emoji correspondente.\n\n💻 = Programador\n🖌️ = Designer`)
  .setColor('#03fc7b')
  
  message.channel.send(embed).then(msg => { 

    msg.react('💻').then(() => msg.react('🖌️')) 

    const filter = (reaction, user) => { // Criando um filtro para quem clicou no emoji
      return ['💻', '🖌️'].includes(reaction.emoji.name) && user.id === message.author.id; 
    };
    msg.awaitReactions(filter, { max: 1, time: 60000, errors: ['time']})
      .then(collected => { 
        const reaction = collected.first();
    
        if (reaction.emoji.name === '💻') {
          message.reply('Tchau'); 
        } 
    
       if (reaction.emoji.name === '🖌️') { 
         message.reply('Oi')
         member.roles.add(role)
                }
            })
      .catch(collected => {
        message.reply('o tempo para escolher excedeu! Tente novamente.');
      });
    })
  }

 exports.help = {
    name: "teste"
}
