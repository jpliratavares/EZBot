const Discord = require("discord.js");
 
exports.run = (bot, message, args) => {
 
    let embed = new Discord.MessageEmbed()
 
    .setColor('RANDOM')
    .setDescription('Foto do servidor:')
    .setTitle(`${message.guild.name}`)
    .setImage(message.guild.iconURL({dynamic: true, size: 2048 }))
 
    message.reply(embed)
 
}
 
exports.help = {
    name: 'servericon'
}