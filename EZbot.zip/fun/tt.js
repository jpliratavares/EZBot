const { RichEmbed } = require("discord.js");

const opcoes = ["🌎","🚀"]  // Supondo que tenha cargo "mundo" e "foguete"


exports.run = async (client, message, args) => {

    let Embed = Discord
   let Discord = Embed
   
    const embed = new Discord.Embed();
    embed.setTitle("**CARGOS**");
    embed.setColor("RANDOM");
    embed.setDescription("Escolha um cargo clicando na reação correspondente:\n") 
    embed.addField("**Cargos**","🌎 - Mundo \n🚀 - Foguete");
    embed.setTimestamp();

    //Envia mensagem richEmbed
    const m = await message.channel.send(embed);

    //Adiciona reações e aguarda 30 segundos por uma escolha do usuário
    const cargoEscolhido = await promptMessage(m, message.author, 30, opcoes);
    
    if (cargoEscolhido === `🚀`){
        var chave = "Foguete";
    }else if (cargoEscolhido === `🌎`) { 
        var chave = "Mundo"
    } else {
        embed.addField("**CARGO NÃO DEFINIDO**", "Use o comando novamente.");
        m.edit(embed);
        message.delete();  // Apaga mensagem do usuario (comando) para um chat mais limpo
        return m.delete(15000)  // Apaga mensagem enviada (embed)
    }; // retorna nada para caso de emoji diferente
    
//    buscando cargo por nome (também pode buscar por ID)
    var cargo = await message.guild.roles.find(role => role.name.toLowerCase() === chave.toLowerCase());

//   buscando membro
    var member = await message.guild.members.find(member => member.id === message.author.id);

    if (cargo == null) { // Caso não exista o cargo com o valor de chave passado
        embed.addField(`CARGO ${chave.toUpperCase()} NAO ENCONTRADO`)
        m.edit(embed)
        message.delete()
        return m.delete(15000)
    }

    // se o membro ja tiver o cargo selecionado, apague o mesmo
    if (member.roles.some(x => x.name === cargo.name)) {
        member.removeRole(cargo.id)
            .then(member => console.log(`${member.user.username} removeu o cargo ${cargo.name}`))
            .catch(err => console.log(err));
        embed.addField("**\nREMOVIDO**",
            `${member.user.username} removeu o cargo ${cargo.name}\n` +
            `Use o comando \`!cargo\` novamente para adicionar ou remover outro cargo.`);
    } 
   // caso contrario, adicione cargo selecionado
    else {
        member.addRole(cargo.id)
            .then(member => {
                var nome = member.user.username;
                console.log(`${nome} adicionou o cargo ${chave}`);       
             })
            .catch(err => console.error);

        embed.addField("**\nADICIONADO**",
                `${member.user.username} adicionou o cargo ${cargo.name}\n` +
                `Use o comando \`!cargo\` novamente para adicionar ou remover outro cargo.`);
    }
    m.edit(embed);
    message.delete();
    m.delete(40000);
    return 

} // fim exports.run

exports.help = {
    name: "cargo"
}