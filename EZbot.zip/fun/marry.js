const Discord = require('discord.js');

exports.run = async (client, message, args) => {

var list = [
  'https://www.intoxianime.com/wp-content/uploads/2018/03/tumblr_p64oqbAUsJ1wl5ucco7_500.gif',
  'https://i.pinimg.com/originals/b8/3b/38/b83b384b1729f5b120e855a62b601cd3.gif',
  'https://2.bp.blogspot.com/-D9IPMvPbI_s/V4pp1KdeCbI/AAAAAAAAMlM/aX8mRtIVxQoO3NQwv8UMhcYRLaxEqf9igCLcB/s640/gif_03.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para casar e que seja seu amor claro!');
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Agora os declaro marido e mulher(esposo)! Já pode beijar a noiva')
        .setColor('#000000')
        .setDescription(`${message.author} acaba de se casar com ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setThumbnail(avatar)
        .setFooter('2020 EZCraft, jpliratavares#4574.')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
};

exports.help = {
    name: 'marry'
}