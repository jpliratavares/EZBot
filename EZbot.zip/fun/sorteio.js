module.exports.run = async (bot, message, args) => {

    console.log(`${message.member} ran the "GiveAway" command`);
    
var item = "";
var time;
var winnerCount
let messageArray = message.content.split(" ");
    
    setTimeout(function() {
        var peopleReacted = embedSent.reactions.get("🎉").users;
        var winners = [];
        
      
        // Checks if fewer people reacted than the winnerCount allows users to win
        if (peopleReacted.length >= winnerCount) {
          winners = peopleReacted;
        } else {
          // Gets as many random users from the peopleReacted as winnerCount allows users to win
          for (var i = 0; i < winnerCount; i++){
            var index = Math.floor(Math.random() * peopleReacted.length);
            winners.push(peopleReacted[index]);
            // After adding a user to winners, remove that item from the array to prevent him from winning multiple times
            peopleReacted.splice(index, 1);
          }
        }
      
        var winnerMsg = "User(s) ";
        for (var i = 0; i < winners.length; i++){
          // Add each winner to the winnerMsg
          winnerMsg += (winners[i].toString() + ", ");
        }
      
        var haveHas;
        if (winners.length === 1){
          haveHas = "has";
        }
        else {
          haveHas = "have";
        }
        message.channel.send(`${winnerMsg} ${haveHas} won ${item}`);
      }, time * 1000); //--conversting seconds into miliseconds
    } 

exports.help = {
    name: 'sorteio'
}
