const ytdl = require('ytdl-core')

module.exports.run = async (client, message, args) => {

   if (!message.member.voiceChannel) return message.channel.send('Please connect to a voice channel to play music.')
   if (message.guild.me.voiceChannel) return message.channel.send('Bot is already connected.')
   if (!args[0]) return message.channel.send('Please put a working Youtube Link.')

   let validate = ytdl.validateURL(args[0])

   if (validate) return message.channel.send('The link is not working.')


   let connection =  await message.member.voiceChannel.join()
   let stream = ytdl(args[0], {filter: 'audioonly'})
   let dispatcher = await connection.playStream(stream)
   dispatcher.on('end', _end => {message.member.voiceChannel.leave()})
}

module.exports.help = {
    name: 'play',
    aliases: []
}