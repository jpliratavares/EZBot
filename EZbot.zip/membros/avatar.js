module.exports = {

    run: function (client, message, args) {
      if (!message.mentions.users.size) {
        return message.channel.send(
          `> **Seu** avatar 🖼 ${message.author.displayAvatarURL()}`
        )
      }
      const avatarList = message.mentions.users.map(
        user => `> **${user.username}'s** avatar 🖼 ${user.displayAvatarURL()}`
      )
  
      return message.channel.send(avatarList)
    },
  
    get help () {
      return {
        name: 'avatar',
        category: 'Info',
        description: 'Mostra o avatar do usuário ou de um bot.',
        usage: 'avatar'
      }
    }
  }