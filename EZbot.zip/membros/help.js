module.exports = {

    run: (client, message, args) => {
      const embed = {
        color: 0xB1103C,
        title: 'Minha lista de comandos',
        description: 'Meu dono é jpliratavares#4574!',
        timestamp: new Date(),
        footer: {
          text: 'EZBot'
        },
        fields: []
      }
  
      let commands = client.commands
  
      if (message.member === null || !message.member.hasPermission('ADMINISTRATOR')) commands = commands.filter(c => !c.help.admin)
  
      commands.forEach(command => {
        if (command.alias) return
        embed.fields.push({
          name: `**ez!${command.help.name}**`,
          value: `*Descrição*: ${command.help.description}
          *Categoria*: ${command.help.category}\n`
        })
      })
  
      message.author.send({
        embed: embed
      })
        .then(() => message.react("732768397229817888"))
        .then(() => message.react("732768397586333797"))
        .then(() => message.react("735968709478318102"))
        .then(() => message.react("735968725689434292"))
        .catch(() => message.reply('eu não tenho permissões para enviar DM para você'))
    },
  
    conf: {},
  
    help: {
      name: 'help',
      category: 'Ajuda',
      description: 'Mostra todos os comandos disponíveis do bot.',
      usage: 'help'
    }
  }